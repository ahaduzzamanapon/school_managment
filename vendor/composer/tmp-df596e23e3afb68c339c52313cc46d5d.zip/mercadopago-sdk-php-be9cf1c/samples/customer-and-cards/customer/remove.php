<?php

    require_once dirname(__FILE__).'/../../index.php';
    require_once dirname(__FILE__).'/create.php';

    $customer->delete();

?>
